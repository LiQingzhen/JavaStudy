package net.sf.cglib.proxy;

interface DI3 extends DI2 {
    public String extra();
}
