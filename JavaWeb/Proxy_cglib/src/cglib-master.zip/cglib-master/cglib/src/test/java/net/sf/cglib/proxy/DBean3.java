package net.sf.cglib.proxy;

public class DBean3 {
    private int age;
    
    public void setAge(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }
}
